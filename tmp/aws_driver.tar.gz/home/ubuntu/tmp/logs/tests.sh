#!/bin/bash

N=3
CELLSIZE=( 5000 )

for n in `seq 1 $N`; do
    for((e=0;e<${#CELLSIZE[@]};e++)); do
	CELL="${CELLSIZE[e]}"
	echo "spark-submit --class FF ~/Research/GeoSpark/target/scala-2.11/pflock_2.11-0.1.jar --input ~/Research/Datasets/LA/LA_sample.tsv --epsilon 25 --distance 25 --mu 10 --delta 3 --master driver --cores 4 --executors 15 --fftimestamp 15 --mfcustomx $CELL --mfcustomy $CELL"
	spark-submit --class FF ~/Research/GeoSpark/target/scala-2.11/pflock_2.11-0.1.jar --input ~/Research/Datasets/LA/LA_sample.tsv --epsilon 50 --distance 25 --mu 5 --delta 3 --master driver --cores 4 --executors 15 --fftimestamp 200 --mfcustomx $CELL --mfcustomy $CELL
    done
done
