#!/bin/bash

N=5
PREFIX_PATH="/home/ubuntu/Research/Datasets/LA/"
FILENAME_SET=( "uniform" )
SUFFIX_PATH=".tsv"
ENTRIES1=1000
ENTRIES2_SET=( 10 20 30 40 50 60 70 80 90 100 )

for((f=0;f<${#FILENAME_SET[@]};f++)); do
    for n in `seq 1 $N`; do
	for((e=0;e<${#ENTRIES2_SET[@]};e++)); do
	    DATASET="${PREFIX_PATH}${FILENAME_SET[f]}${SUFFIX_PATH}"
	    ENTRIES2="${ENTRIES2_SET[e]}"
	    echo "spark-submit --class MF_QuadTree2 ~/Research/GeoSpark/target/scala-2.11/pflock_2.11-0.1.jar --input $DATASET --epsilon 100 --mu 5 --host driver --cores 4 --executors 15 --levels 4096 --entries $ENTRIES1 --mfpartitions $ENTRIES2 --info --portui 4040 --output ~/tmp/apps03/"
	    spark-submit --class MF_QuadTree2 ~/Research/GeoSpark/target/scala-2.11/pflock_2.11-0.1.jar --input $DATASET --epsilon 100 --mu 5 --host driver --cores 4 --executors 15 --levels 4096 --entries $ENTRIES1 --mfpartitions $ENTRIES2 --info --portui 4040 --output ~/tmp/apps03/
	done
    done
done
